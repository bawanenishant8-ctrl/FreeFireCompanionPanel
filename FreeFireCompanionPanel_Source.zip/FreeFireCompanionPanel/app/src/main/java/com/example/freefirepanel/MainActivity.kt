package com.example.freefirepanel

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(24), dp(32), dp(24), dp(24))
            setBackgroundColor(Color.rgb(16, 16, 20))
        }

        val title = TextView(this).apply {
            text = "FREE FIRE\nCOMPANION PANEL"
            textSize = 25f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        page.addView(title, LinearLayout.LayoutParams(-1, dp(100)))

        val subtitle = TextView(this).apply {
            text = "Legitimate floating match-stat tracker"
            textSize = 14f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
        }
        page.addView(subtitle, LinearLayout.LayoutParams(-1, dp(42)))

        val info = TextView(this).apply {
            text = "Tracks headshots you enter manually. The location-style badge is a visual status only; it does not reveal enemy positions or read Free Fire game data."
            textSize = 15f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(18), dp(12), dp(18))
        }
        page.addView(info, LinearLayout.LayoutParams(-1, dp(150)))

        val start = Button(this).apply {
            text = "ENABLE FLOATING PANEL"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    val i = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName"))
                    startActivity(i)
                    Toast.makeText(this@MainActivity, "Allow display over other apps, then return and tap Enable.", Toast.LENGTH_LONG).show()
                } else {
                    startService(Intent(this@MainActivity, OverlayService::class.java).setAction(OverlayService.ACTION_SHOW))
                    Toast.makeText(this@MainActivity, "Floating panel enabled", Toast.LENGTH_SHORT).show()
                }
            }
        }
        page.addView(start, LinearLayout.LayoutParams(-1, dp(56)))

        val stop = Button(this).apply {
            text = "STOP FLOATING PANEL"
            setOnClickListener {
                stopService(Intent(this@MainActivity, OverlayService::class.java))
                Toast.makeText(this@MainActivity, "Panel stopped", Toast.LENGTH_SHORT).show()
            }
        }
        val stopParams = LinearLayout.LayoutParams(-1, dp(56))
        stopParams.topMargin = dp(12)
        page.addView(stop, stopParams)

        val note = TextView(this).apply {
            text = "Tip: Move the panel by dragging its top bar. Tap +1 to count a headshot."
            textSize = 13f
            setTextColor(Color.GRAY)
            gravity = Gravity.CENTER
        }
        val noteParams = LinearLayout.LayoutParams(-1, dp(80))
        page.addView(note, noteParams)

        setContentView(page)
    }
}
