package com.example.freefirepanel

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class OverlayService : Service() {
    companion object {
        const val ACTION_SHOW = "com.example.freefirepanel.SHOW"
        private const val CHANNEL_ID = "ff_panel_channel"
    }

    private lateinit var windowManager: WindowManager
    private var panel: View? = null
    private var headshots = 0
    private lateinit var countView: TextView

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        val notification: Notification = if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, CHANNEL_ID)
                .setContentTitle("FF Companion Panel")
                .setContentText("Floating match-stat tracker is active")
                .setSmallIcon(android.R.drawable.ic_menu_mylocation)
                .build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
                .setContentTitle("FF Companion Panel")
                .setContentText("Floating match-stat tracker is active")
                .setSmallIcon(android.R.drawable.ic_menu_mylocation)
                .build()
        }
        startForeground(7, notification)
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        showPanel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (panel == null) showPanel()
        return START_STICKY
    }

    private fun showPanel() {
        if (panel != null) return

        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(8), dp(10), dp(8))
            setBackgroundColor(Color.rgb(25, 22, 28))
        }

        val top = TextView(this).apply {
            text = "🎯  FF STATS     ⋮⋮"
            textSize = 14f
            setTextColor(Color.WHITE)
            setPadding(dp(6), dp(5), dp(6), dp(10))
        }
        outer.addView(top)

        countView = TextView(this).apply {
            text = "HEADSHOTS  $headshots"
            textSize = 18f
            setTextColor(Color.rgb(255, 80, 65))
            setPadding(dp(6), dp(8), dp(6), dp(8))
        }
        outer.addView(countView)

        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val add = Button(this).apply {
            text = "+1"
            setOnClickListener { headshots++; updateCount() }
        }
        val subtract = Button(this).apply {
            text = "−1"
            setOnClickListener { if (headshots > 0) headshots--; updateCount() }
        }
        val reset = Button(this).apply {
            text = "RESET"
            setOnClickListener { headshots = 0; updateCount() }
        }
        controls.addView(add, LinearLayout.LayoutParams(0, dp(44), 1f))
        controls.addView(subtract, LinearLayout.LayoutParams(0, dp(44), 1f))
        controls.addView(reset, LinearLayout.LayoutParams(0, dp(44), 1f))
        outer.addView(controls)

        val location = TextView(this).apply {
            text = "📍 LOCATION INDICATOR  •  SAFE"
            textSize = 11f
            setTextColor(Color.rgb(130, 220, 150))
            setPadding(dp(6), dp(8), dp(6), dp(3))
        }
        outer.addView(location)

        top.setOnTouchListener(object : View.OnTouchListener {
            var initialX = 0
            var initialY = 0
            var touchX = 0f
            var touchY = 0f
            override fun onTouch(v: View, event: MotionEvent): Boolean {
                val params = panel?.layoutParams as? WindowManager.LayoutParams ?: return false
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        initialX = params.x; initialY = params.y
                        touchX = event.rawX; touchY = event.rawY
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        params.x = initialX + (event.rawX - touchX).toInt()
                        params.y = initialY + (event.rawY - touchY).toInt()
                        windowManager.updateViewLayout(panel, params)
                        return true
                    }
                }
                return false
            }
        })

        val type = if (Build.VERSION.SDK_INT >= 26)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE

        val params = WindowManager.LayoutParams(
            dp(260), WindowManager.LayoutParams.WRAP_CONTENT, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(12)
            y = dp(110)
        }

        panel = outer
        windowManager.addView(outer, params)
    }

    private fun updateCount() {
        countView.text = "HEADSHOTS  $headshots"
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL_ID, "FF Panel", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        panel?.let { windowManager.removeView(it) }
        panel = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
