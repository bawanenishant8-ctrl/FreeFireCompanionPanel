# Free Fire Companion Panel (Android Studio project)

This is a legitimate floating companion panel. It provides a manual headshot counter and a decorative location-status indicator.

## What it does
- Displays a floating panel over other apps after the user grants Android's overlay permission.
- `+1`, `-1`, and `RESET` buttons update a manual headshot count.
- The location badge is only a visual status indicator. It does not read Free Fire internals, show enemy positions, or provide live in-game coordinates.

## Build an APK
1. Install Android Studio on a computer.
2. Extract this ZIP.
3. In Android Studio, choose **Open** and select the `FreeFireCompanionPanel` folder.
4. Let Gradle sync. If prompted, install Android SDK 35 and the Android Gradle Plugin dependencies.
5. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. On your Android phone, install the APK you built. You may need to allow installation from that source.
7. Open **FF Companion Panel**, tap **Enable Floating Panel**, and allow **Display over other apps**.
8. Return to the app and tap **Enable Floating Panel** again. Open Free Fire; drag the panel by its top bar.

## Notes
- This ZIP contains Android Studio source code, not a prebuilt/signed APK.
- Android version and device-manufacturer restrictions may affect overlays.
- Use only in ways allowed by Free Fire's rules. The app does not modify the game or automate aiming.
